using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace Reflectable
{
    /// <summary>Self-contained, data-oriented prototype controller. Deliberately uses swept circle/rect tests for deterministic ricochets.</summary>
    public sealed class ReflectableBootstrap : MonoBehaviour
    {
        const int Cols = 7, Rows = 7;
        const float Left = -7f, Right = 7f, Ceiling = 5.2f, Bottom = -5.4f, Cell = 1.85f;
        readonly Color cream = new Color(1f,.961f,.914f), pink = new Color(.969f,.718f,.824f), blue = new Color(.663f,.867f,.961f), lavender = new Color(.784f,.714f,.91f), ink = new Color(.294f,.271f,.388f);
        Camera cam; Sprite square, circle; Canvas canvas; Font font;
        readonly List<Block> blocks = new(); readonly List<Ball> balls = new(); readonly List<GameObject> arenaObjects = new();
        readonly Dictionary<string,int> skills = new() { {"POWER",0},{"RICOCHET",0},{"EXTRA BALL",0},{"MAX HP",0} };
        readonly List<GameObject> screenObjects = new();
        Text hpText, scoreText, gemsText, turnText, comboText, expText, characterText;
        bool aiming, gameOver, paused, endingTurn; int turn, hp=100, maxHp=100, score, gems, level=1, exp, sp, combo, maxCombo, destroyed, ricochets, gachaCost=2;
        string character="MIMI"; int rank=1; float shotDamage=5; int ballsToLaunch; string savePath;

        [Serializable] class SaveData { public bool valid; public int turn,hp,maxHp,score,gems,level,exp,sp,gachaCost; public string character; public int rank; public List<int> skill = new(); public List<CellSave> cells = new(); }
        [Serializable] class CellSave { public int r,c,hp,max; public string type; }
        sealed class Block { public int r,c,hp,max; public string type; public GameObject go; public Text label; public float pulse; }
        sealed class Ball { public Vector2 p,v; public float life=20f, damage; public int bounces; public GameObject go; public readonly HashSet<Block> recent = new(); }

        void Awake()
        {
            Application.targetFrameRate = 120; savePath = Path.Combine(Application.persistentDataPath,"reflectable_save.json");
            bool isGameScene=SceneManager.GetActiveScene().name == "Game";
            if(isGameScene)
            {
                // The editor builder stores an inactive presentation template. Older generated scenes
                // may still have it active, so turn it off before this runtime-owned presentation is made.
                foreach(var existingCanvas in FindObjectsByType<Canvas>(FindObjectsSortMode.None)) existingCanvas.gameObject.SetActive(false);
                var assembledArena=GameObject.Find("Arena"); if(assembledArena) assembledArena.SetActive(false);
                var assembledPlayer=GameObject.Find("Player"); if(assembledPlayer) assembledPlayer.SetActive(false);
            }
            CreateBase();
            if (isGameScene) StartRun(false);
            else ShowMainMenu();
        }
        void CreateBase()
        {
            cam = Camera.main; if (!cam) { var c=new GameObject("Pastel Camera"); cam=c.AddComponent<Camera>(); cam.orthographic=true; cam.orthographicSize=6.2f; c.tag="MainCamera"; }
            cam.transform.position=new Vector3(0f,0f,-10f);
            cam.backgroundColor=cream; square=MakeSprite(false); circle=MakeSprite(true); font=Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            var cg=new GameObject("Canvas"); canvas=cg.AddComponent<Canvas>(); canvas.renderMode=RenderMode.ScreenSpaceOverlay; var scaler=cg.AddComponent<CanvasScaler>(); scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize; scaler.referenceResolution=new Vector2(1920,1080); cg.AddComponent<GraphicRaycaster>();
            if (!FindAnyObjectByType<EventSystem>()) { var e=new GameObject("EventSystem"); e.AddComponent<EventSystem>(); e.AddComponent<InputSystemUIInputModule>(); }
        }
        Sprite MakeSprite(bool round) { var t=new Texture2D(64,64); for(int y=0;y<64;y++)for(int x=0;x<64;x++){float d=Vector2.Distance(new Vector2(x,y),new Vector2(31.5f,31.5f));t.SetPixel(x,y, !round||d<31?Color.white:Color.clear);} t.Apply(); return Sprite.Create(t,new Rect(0,0,64,64),new Vector2(.5f,.5f),64); }
        GameObject World(string n, Vector2 p, Vector2 s, Color c, bool round=false) { var g=new GameObject(n);g.transform.position=new Vector3(p.x,p.y,0f);g.transform.localScale=s;var sr=g.AddComponent<SpriteRenderer>();sr.sprite=round?circle:square;sr.color=c;sr.sortingOrder=n.Contains("Block")?10:n=="Ricochet"?30:n=="Mimi"||n=="Wand"?40:n.Contains("Wall")?-20:0;arenaObjects.Add(g);return g; }
        Text Label(string value, Transform parent, Vector2 pos, Vector2 size, int fs=28, TextAnchor align=TextAnchor.MiddleCenter)
        { var g=new GameObject("Text");g.transform.SetParent(parent,false);var rt=g.AddComponent<RectTransform>();rt.anchoredPosition=pos;rt.sizeDelta=size;var t=g.AddComponent<Text>();t.font=font;t.text=value;t.fontSize=fs;t.alignment=align;t.color=ink;t.horizontalOverflow=HorizontalWrapMode.Overflow;t.verticalOverflow=VerticalWrapMode.Overflow;return t; }
        Button Button(string value, Transform parent, Vector2 pos, Vector2 size, Action click)
        { var g=new GameObject(value);g.transform.SetParent(parent,false);var rt=g.AddComponent<RectTransform>();rt.anchoredPosition=pos;rt.sizeDelta=size;var im=g.AddComponent<Image>();im.sprite=square;im.color=lavender;var b=g.AddComponent<Button>();b.targetGraphic=im;b.onClick.AddListener(()=>click());var t=Label(value,g.transform,Vector2.zero,size,25);t.raycastTarget=false;return b; }
        void ClearScreen(){foreach(var g in screenObjects) if(g)Destroy(g);screenObjects.Clear();}
        Transform Panel(string name){var g=new GameObject(name);g.transform.SetParent(canvas.transform,false);screenObjects.Add(g);return g.transform;}

        public void ShowMainMenu()
        { ClearGameplay(); ClearScreen(); aiming=false; var p=Panel("Main Menu"); var bg=new GameObject("Backdrop");bg.transform.SetParent(p,false);var r=bg.AddComponent<RectTransform>();r.anchorMin=Vector2.zero;r.anchorMax=Vector2.one;r.offsetMin=r.offsetMax=Vector2.zero;var i=bg.AddComponent<Image>();i.color=cream;
            var title=Label("REFLECTABLE",p,new Vector2(0,230),new Vector2(1000,130),72);title.color=new Color(.49f,.42f,.65f);
            Label("A tiny pastel ricochet adventure",p,new Vector2(0,155),new Vector2(800,50),26);
            bool canResume=File.Exists(savePath) && JsonUtility.FromJson<SaveData>(File.ReadAllText(savePath)).valid;
            if(canResume) Button("RESUME GAME",p,new Vector2(0,55),new Vector2(390,64),()=>StartRun(true));
            Button("PLAY GAME",p,new Vector2(0,canResume?-30:55),new Vector2(390,64),()=>ShowMapSelect());
            int best=PlayerPrefs.GetInt("ReflectableBest",0);Label("BEST SCORE : "+best,p,new Vector2(0,-145),new Vector2(500,40),24);
            Button("SETTINGS",p,new Vector2(0,-220),new Vector2(300,52),()=>Popup("SETTINGS\n\nMaster Volume   100%\nMusic Volume      70%\nSFX Volume         85%\nScreen Shake     60%\n\nFullscreen is enabled in the player settings.",ShowMainMenu));
            Button("EXIT",p,new Vector2(0,-290),new Vector2(220,48),()=>Application.Quit());
        }
        int mapIndex;
        void ShowMapSelect(){ClearScreen();var p=Panel("Map Select");Label("MAP SELECT",p,new Vector2(0,300),new Vector2(800,80),50);Button("‹",p,new Vector2(-440,0),new Vector2(80,80),()=>{mapIndex=(mapIndex+2)%3;ShowMapSelect();});Button("›",p,new Vector2(440,0),new Vector2(80,80),()=>{mapIndex=(mapIndex+1)%3;ShowMapSelect();});string[] names={"01  BLOOM GARDEN","02  SUNSET ROOFTOP","03  DREAMY MIDNIGHT"};bool unlocked=mapIndex==0 || PlayerPrefs.GetInt("ReflectableMaps",0)>=mapIndex;var card=new GameObject("Map Card");card.transform.SetParent(p,false);var rt=card.AddComponent<RectTransform>();rt.sizeDelta=new Vector2(650,310);var im=card.AddComponent<Image>();im.color=unlocked?pink:Color.Lerp(pink,Color.gray,.7f);Label(names[mapIndex],card.transform,new Vector2(0,55),new Vector2(600,70),38);Label(unlocked?"Ready to bounce!":"LOCKED\nComplete the previous garden to unlock",card.transform,new Vector2(0,-25),new Vector2(580,90),24);if(unlocked)Button("PLAY",p,new Vector2(0,-245),new Vector2(260,58),()=>SceneManager.LoadScene("Game"));Button("BACK",p,new Vector2(0,-320),new Vector2(200,44),ShowMainMenu);}
        void Popup(string text, Action onBack=null){var p=Panel("Popup");var g=new GameObject("Window");g.transform.SetParent(p,false);var rt=g.AddComponent<RectTransform>();rt.sizeDelta=new Vector2(620,450);var im=g.AddComponent<Image>();im.color=cream;Label(text,g.transform,new Vector2(0,30),new Vector2(570,330),26);Button("BACK",g.transform,new Vector2(0,-170),new Vector2(200,50),()=>{ClearScreen();if(onBack!=null)onBack();else BuildHud();});}

        void StartRun(bool resume)
        { ClearScreen(); ClearGameplay(); if(resume) LoadRun(); else {turn=0;hp=maxHp=100;score=gems=exp=sp=combo=maxCombo=destroyed=ricochets=0;level=1;gachaCost=2;character="MIMI";rank=1;foreach(var k in new List<string>(skills.Keys))skills[k]=0; SpawnInitial();} BuildArena();BuildHud();StartTurn(); }
        void BuildArena(){World("Left Wall",new Vector2(Left-.15f,0),new Vector2(.25f,11.5f),lavender);World("Right Wall",new Vector2(Right+.15f,0),new Vector2(.25f,11.5f),lavender);World("Ceiling",new Vector2(0,Ceiling+.15f),new Vector2(14.5f,.25f),lavender);var player=World("Mimi",new Vector2(0,-4.85f),new Vector2(.9f,.9f),pink,true);var arm=World("Wand",new Vector2(.35f,-4.56f),new Vector2(.5f,.12f),ink);arm.transform.parent=player.transform;}
        void BuildHud(){var p=Panel("HUD");hpText=Label("",p,new Vector2(-790,465),new Vector2(300,55),28);scoreText=Label("",p,new Vector2(0,465),new Vector2(500,55),28);gemsText=Label("",p,new Vector2(790,465),new Vector2(300,55),28);turnText=Label("",p,new Vector2(0,420),new Vector2(400,40),22);comboText=Label("",p,new Vector2(0,320),new Vector2(700,80),42);expText=Label("",p,new Vector2(-670,-465),new Vector2(550,50),22);
            string[] names={"POWER","RICOCHET","EXTRA BALL","MAX HP"};for(int n=0;n<4;n++){string s=names[n];Button(s+" +",p,new Vector2(-410+n*270,-465),new Vector2(245,55),()=>Upgrade(s));} characterText=Label("",p,new Vector2(550,-405),new Vector2(480,40),20);Button("CHARACTER DRAW",p,new Vector2(650,-465),new Vector2(280,55),ShowGacha); RefreshHud();}
        void SpawnInitial(){for(int r=0;r<3;r++)SpawnRow(r);}
        void SpawnRow(int row){int count=Mathf.Min(Cols-1,UnityEngine.Random.Range(2,5)+turn/8);var chosen=new HashSet<int>();for(int i=0;i<count;i++){int c;do c=UnityEngine.Random.Range(0,Cols);while(!chosen.Add(c));string type=UnityEngine.Random.value<.10f?"GEM":UnityEngine.Random.value<.16f?"BOMB":"NORMAL";CreateBlock(row,c,Mathf.RoundToInt(5+turn*2+UnityEngine.Random.Range(0,10)),type);}}
        void CreateBlock(int r,int c,int blockHp,string type){var b=new Block{r=r,c=c,hp=blockHp,max=blockHp,type=type};Color baseC=type=="GEM"?blue:type=="BOMB"?pink:lavender;float intensity=Mathf.Clamp01(blockHp/50f);var g=World(type+" Block",CellPos(r,c),Vector2.one*1.35f,Color.Lerp(cream,baseC,.35f+.55f*intensity));b.go=g;var cv=new GameObject("HP");cv.transform.SetParent(g.transform,false);var cn=cv.AddComponent<Canvas>();cn.renderMode=RenderMode.WorldSpace;cn.worldCamera=cam;cn.sortingOrder=10;var cr=cv.GetComponent<RectTransform>();cr.sizeDelta=new Vector2(130,55);cr.localScale=Vector3.one*.012f;b.label=Label(type=="BOMB"?"✦\n"+blockHp:type=="GEM"?"◆\n"+blockHp:blockHp.ToString(),cv.transform,Vector2.zero,new Vector2(130,90),38);blocks.Add(b);}
        Vector2 CellPos(int r,int c)=>new Vector2((c-(Cols-1)*.5f)*Cell,Ceiling-.85f-r*1.25f);
        void StartTurn(){turn++;aiming=true;combo=0;RefreshHud();Debug.Log("Reflectable: Turn "+turn+" started");}
        void Update(){if(gameOver)return;if(Keyboard.current!=null&&Keyboard.current.escapeKey.wasPressedThisFrame){paused=!paused;if(paused)Popup("PAUSED\n\nYour last safe turn is saved.");else{ClearScreen();BuildHud();}} if(!aiming||paused)return;var mouse=Mouse.current;if(mouse!=null&&mouse.leftButton.wasPressedThisFrame&&!EventSystem.current.IsPointerOverGameObject())Fire();}
        void Fire(){var mp=cam.ScreenToWorldPoint(Mouse.current.position.ReadValue());Vector2 d=((Vector2)mp-new Vector2(0,-4.65f)).normalized;if(d.y<.12f)return;aiming=false;ballsToLaunch=1+skills["EXTRA BALL"]+CharacterBalls();shotDamage=5f*(1+.1f*skills["POWER"])*(character=="LUNE"?.75f:1f);StartCoroutine(Launch(d));}
        int CharacterBalls()=>character=="LUNE"?(rank>=5?3:rank>=3?2:1):0;
        IEnumerator Launch(Vector2 d){for(int i=0;i<ballsToLaunch;i++){CreateBall(d);yield return new WaitForSeconds(.09f);} }
        void CreateBall(Vector2 d){var b=new Ball{p=new Vector2(0,-4.45f),v=d*12f,damage=shotDamage};b.go=World("Ricochet",b.p,Vector2.one*.26f,blue,true);balls.Add(b);}
        void FixedUpdate(){if(balls.Count==0)return;for(int i=balls.Count-1;i>=0;i--){var b=balls[i];StepBall(b,Time.fixedDeltaTime);if(b.life<=0||b.p.y<Bottom){Destroy(b.go);balls.RemoveAt(i);}}if(!aiming&&balls.Count==0&&!endingTurn)StartCoroutine(EndTurn());}
        void StepBall(Ball b,float dt){b.life-=dt;Vector2 next=b.p+b.v*dt; if(next.x<Left||next.x>Right){b.v.x=-b.v.x;next.x=Mathf.Clamp(next.x,Left,Right);WallBounce(b);}if(next.y>Ceiling){b.v.y=-Mathf.Abs(b.v.y);next.y=Ceiling;WallBounce(b);}foreach(var block in blocks.ToArray()){if(block.go&&RectContains(block, next)&&!b.recent.Contains(block)){b.recent.Add(block);Damage(block,Mathf.Max(1,Mathf.RoundToInt(b.damage)),b);Vector2 delta=next-CellPos(block.r,block.c);if(Mathf.Abs(delta.x)>Mathf.Abs(delta.y))b.v.x=-b.v.x;else b.v.y=-b.v.y;break;}}b.p=next;b.recent.RemoveWhere(x=>!RectContains(x,b.p));b.go.transform.position=b.p;}
        bool RectContains(Block x,Vector2 p){Vector2 q=CellPos(x.r,x.c);return Mathf.Abs(p.x-q.x)<.73f&&Mathf.Abs(p.y-q.y)<.73f;}
        void WallBounce(Ball b){b.bounces++;ricochets++;float bonus=.03f*skills["RICOCHET"]+(character=="ECHO"?.03f*rank:0);b.damage*=1+bonus;}
        void Damage(Block b,int amount,Ball ball){if(!b.go)return;b.hp-=amount;combo++;maxCombo=Mathf.Max(maxCombo,combo);score+=Mathf.RoundToInt(10*(1+Mathf.Min(combo,50)*.02f));b.label.text=(b.type=="BOMB"?"✦\n":b.type=="GEM"?"◆\n":"")+Mathf.Max(0,b.hp);StartCoroutine(Punch(b.go.transform));if(b.hp<=0)DestroyBlock(b);RefreshHud();}
        IEnumerator Punch(Transform t){if(!t)yield break;t.localScale=Vector3.one*1.55f;yield return new WaitForSeconds(.08f);if(t)t.localScale=Vector3.one*1.35f;}
        void DestroyBlock(Block b){if(!blocks.Remove(b))return;destroyed++;score+=b.type=="GEM"?250:b.type=="BOMB"?150:100;GainExp(5+b.max/4);if(b.type=="GEM")gems++;if(b.type=="BOMB"){foreach(var other in blocks.ToArray())if(Mathf.Abs(other.r-b.r)<=1&&Mathf.Abs(other.c-b.c)<=1)Damage(other,Mathf.Max(4,b.max/2),null);}Destroy(b.go);}
        void GainExp(int amount){exp+=amount;int need=25+level*15;while(exp>=need){exp-=need;level++;sp++;StartCoroutine(Flash("LEVEL UP!  +1 SP"));need=25+level*15;}}
        IEnumerator Flash(string msg){comboText.text=msg;yield return new WaitForSeconds(1f);RefreshHud();}
        IEnumerator EndTurn(){endingTurn=true;yield return new WaitForSeconds(.35f);foreach(var b in blocks) {b.r++;StartCoroutine(Move(b.go.transform,CellPos(b.r,b.c)));}yield return new WaitForSeconds(.25f);foreach(var b in blocks.ToArray())if(b.r>=Rows){hp-=b.hp;blocks.Remove(b);Destroy(b.go);}SpawnRow(0);if(hp<=0){GameOver();yield break;}SaveRun();endingTurn=false;StartTurn();}
        IEnumerator Move(Transform t,Vector2 target){Vector2 start=t.position;for(float x=0;x<.25f;x+=Time.deltaTime){if(t)t.position=Vector2.Lerp(start,target,x/.25f);yield return null;}if(t)t.position=target;}
        void Upgrade(string name){if(!aiming)return;int cost=name=="EXTRA BALL"?2:1;if(sp<cost)return;sp-=cost;skills[name]++;if(name=="MAX HP"){maxHp+=15;hp=Mathf.Min(maxHp,hp+15);}RefreshHud();}
        void ShowGacha(){if(!aiming)return;var p=Panel("Character Draw");var g=new GameObject("Window");g.transform.SetParent(p,false);var rt=g.AddComponent<RectTransform>();rt.sizeDelta=new Vector2(680,400);var im=g.AddComponent<Image>();im.color=cream;Label("CHARACTER DRAW\n\nCURRENT: "+character+" "+new string('★',rank)+"\nCost: "+gachaCost+" Gems",g.transform,new Vector2(0,55),new Vector2(620,260),28);Button("SUMMON",g.transform,new Vector2(0,-130),new Vector2(250,60),()=>{if(gems>=gachaCost){gems-=gachaCost;gachaCost++;float r=UnityEngine.Random.value;rank=r<.35?1:r<.65?2:r<.85?3:r<.95?4:5;character=new[]{"MIMI","ECHO","LUNE"}[UnityEngine.Random.Range(0,3)];ClearScreen();BuildHud();StartCoroutine(Flash("NEW "+character+" "+new string('★',rank)));} });Button("BACK",g.transform,new Vector2(0,-200),new Vector2(180,45),()=>{ClearScreen();BuildHud();});}
        void RefreshHud(){if(hpText==null)return;hpText.text="HP  "+hp+" / "+maxHp;scoreText.text="SCORE  "+score;gemsText.text="◆  "+gems;turnText.text="TURN "+turn;comboText.text=combo>=10?combo+" HIT!":"";expText.text="LV "+level+"    EXP "+exp+" / "+(25+level*15)+"    SP "+sp;characterText.text=character+" "+new string('★',rank)+"   |   "+skills["POWER"]+" POW  "+skills["RICOCHET"]+" RIC";}
        void GameOver(){gameOver=true;aiming=false;PlayerPrefs.SetInt("ReflectableBest",Mathf.Max(PlayerPrefs.GetInt("ReflectableBest",0),score));PlayerPrefs.Save();if(File.Exists(savePath))File.Delete(savePath);ClearScreen();var p=Panel("Run Over");Label("RUN OVER",p,new Vector2(0,250),new Vector2(800,90),60);Label("SCORE  "+score+"\nBEST SCORE  "+PlayerPrefs.GetInt("ReflectableBest",0)+"\nTURN  "+turn+"   BLOCKS DESTROYED  "+destroyed+"\nMAX COMBO  "+maxCombo+"   RICOCHETS  "+ricochets+"\nGEMS COLLECTED  "+gems,p,new Vector2(0,20),new Vector2(800,330),28);Button("RETRY",p,new Vector2(-150,-250),new Vector2(240,58),()=>StartRun(false));Button("MAIN MENU",p,new Vector2(150,-250),new Vector2(240,58),ShowMainMenu);}
        void SaveRun(){var d=new SaveData{valid=true,turn=turn,hp=hp,maxHp=maxHp,score=score,gems=gems,level=level,exp=exp,sp=sp,gachaCost=gachaCost,character=character,rank=rank};foreach(var s in skills)d.skill.Add(s.Value);foreach(var b in blocks)d.cells.Add(new CellSave{r=b.r,c=b.c,hp=b.hp,max=b.max,type=b.type});File.WriteAllText(savePath,JsonUtility.ToJson(d));Debug.Log("Reflectable: Run saved");}
        void LoadRun(){var d=JsonUtility.FromJson<SaveData>(File.ReadAllText(savePath));turn=d.turn;hp=d.hp;maxHp=d.maxHp;score=d.score;gems=d.gems;level=d.level;exp=d.exp;sp=d.sp;gachaCost=d.gachaCost;character=d.character;rank=d.rank;int z=0;foreach(var k in new List<string>(skills.Keys))skills[k]=z<d.skill.Count?d.skill[z++]:0;foreach(var c in d.cells)CreateBlock(c.r,c.c,c.max,c.type);foreach(var b in blocks)b.hp=d.cells.Find(x=>x.r==b.r&&x.c==b.c).hp;}
        void ClearGameplay(){foreach(var g in arenaObjects)if(g)Destroy(g);arenaObjects.Clear();blocks.Clear();balls.Clear();gameOver=false;endingTurn=false;}
    }
}
